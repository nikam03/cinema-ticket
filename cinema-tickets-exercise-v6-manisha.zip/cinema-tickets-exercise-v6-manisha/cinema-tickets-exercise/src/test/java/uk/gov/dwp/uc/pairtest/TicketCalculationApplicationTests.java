package uk.gov.dwp.uc.pairtest;

import org.junit.jupiter.api.Test;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.web.server.LocalServerPort;
import org.springframework.context.ConfigurableApplicationContext;

import java.util.Collections;

import static org.junit.jupiter.api.Assertions.assertTrue;

@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
public class TicketCalculationApplicationTests {

    @LocalServerPort private int port;

    /** Application Loads without exception */
    @Test
    void contextLoads(){
        TicketPurchaseApplication.main(new String[] {});
    }

    /** Test Successful start up of Application without exception */
    @Test
    void applicationStarts(){
        final SpringApplication app = new SpringApplication(TicketPurchaseApplication.class);
        app.setDefaultProperties(Collections.singletonMap("server.port", String.valueOf(port)));

        final ConfigurableApplicationContext context = app.run();

        assertTrue(context.isActive());

        context.close();
    }
}
