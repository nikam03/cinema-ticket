package uk.gov.dwp.uc.pairtest.controller;


import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.web.client.TestRestTemplate;
import org.springframework.boot.web.server.LocalServerPort;
import org.springframework.http.HttpEntity;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import thirdparty.paymentgateway.TicketPaymentService;
import uk.gov.dwp.uc.pairtest.domain.TicketPurchaseRequest;
import uk.gov.dwp.uc.pairtest.domain.TicketPurchaseResponse;
import uk.gov.dwp.uc.pairtest.domain.TicketRequest;
import uk.gov.dwp.uc.pairtest.exception.ExceptionResponse;

import java.io.File;
import java.io.IOException;

import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertTrue;

@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
public class TicketBookingControllerTests {

    @LocalServerPort
    private int port;

    @Autowired
    private TestRestTemplate testRestTemplate;

    @InjectMocks
    private TicketBookingController ticketBookingController;

    @Mock
    private TicketPaymentService ticketPaymentService;

    @Test
    public void testValidCinemaTicketBooking() throws IOException {
        final TicketPurchaseRequest ticketPurchaseRequest = new ObjectMapper().readValue(new File("src/test/resources/purchase_success.json"),TicketPurchaseRequest.class );
        HttpEntity<TicketPurchaseRequest> ticketPurchaseRequestHttpEntity = new HttpEntity<>(ticketPurchaseRequest);
        ResponseEntity<TicketPurchaseResponse> ticketPurchaseResponse = testRestTemplate.
                postForEntity("http://localhost:" + port + "/consumer-tickets-ms/tickets/tickets-pricecalc-v1/tickets/purchase",ticketPurchaseRequestHttpEntity, TicketPurchaseResponse.class);
        assertNotNull(ticketPurchaseResponse);
        assertTrue(ticketPurchaseResponse.getBody().totalPrice()==330);
        assertTrue(ticketPurchaseResponse.getBody().noOfSeats()==18);
    }

    @Test
    public void testValidCinemaTicketBookingWithInfant() throws IOException {
        final TicketPurchaseRequest ticketPurchaseRequest = new ObjectMapper().readValue(new File("src/test/resources/purchase_success_infant.json"),TicketPurchaseRequest.class );
        HttpEntity<TicketPurchaseRequest> ticketPurchaseRequestHttpEntity = new HttpEntity<>(ticketPurchaseRequest);
        ResponseEntity<TicketPurchaseResponse> ticketPurchaseResponse = testRestTemplate.
                postForEntity("http://localhost:" + port + "/consumer-tickets-ms/tickets/tickets-pricecalc-v1/tickets/purchase",ticketPurchaseRequestHttpEntity, TicketPurchaseResponse.class);
        assertNotNull(ticketPurchaseResponse);
        assertTrue(ticketPurchaseResponse.getBody().totalPrice()==220);
        assertTrue(ticketPurchaseResponse.getBody().noOfSeats()==12);
    }

    @Test
    public void testInValidCinemaTicketBookingWithNoAdult() throws IOException {
        final TicketPurchaseRequest ticketPurchaseRequest = new ObjectMapper().readValue(new File("src/test/resources/invalid_purchase_no_adult.json"),TicketPurchaseRequest.class );
        HttpEntity<TicketPurchaseRequest> ticketPurchaseRequestHttpEntity = new HttpEntity<>(ticketPurchaseRequest);
        ResponseEntity<ExceptionResponse> exceptionResponse =  testRestTemplate.
                postForEntity("http://localhost:" + port + "/consumer-tickets-ms/tickets/tickets-pricecalc-v1/tickets/purchase",ticketPurchaseRequestHttpEntity, ExceptionResponse.class);
        assertNotNull(exceptionResponse);
        assertTrue(exceptionResponse.getBody().getMessage().contains("Invalid"));
    }

    @Test
    public void testInValidCinemaTicketBookingMoreThans20Tickets() throws IOException {
        final TicketPurchaseRequest ticketPurchaseRequest = new ObjectMapper().readValue(new File("src/test/resources/invalid_purchase_more_than_20.json"),TicketPurchaseRequest.class );
        HttpEntity<TicketPurchaseRequest> ticketPurchaseRequestHttpEntity = new HttpEntity<>(ticketPurchaseRequest);
        ResponseEntity<ExceptionResponse> exceptionResponse =  testRestTemplate.
                postForEntity("http://localhost:" + port + "/consumer-tickets-ms/tickets/tickets-pricecalc-v1/tickets/purchase",ticketPurchaseRequestHttpEntity, ExceptionResponse.class);
        assertNotNull(exceptionResponse);
        assertTrue(exceptionResponse.getBody().getMessage().contains("Sorry"));
    }

    @Test
    public void testInValidCinemaTicketBookingInvalidPurchaseOfTickets() throws IOException {
        final TicketPurchaseRequest ticketPurchaseRequest = new ObjectMapper().readValue(new File("src/test/resources/invalid_purchase_request.json"),TicketPurchaseRequest.class );
        HttpEntity<TicketPurchaseRequest> ticketPurchaseRequestHttpEntity = new HttpEntity<>(ticketPurchaseRequest);
        ResponseEntity<ExceptionResponse> exceptionResponse =  testRestTemplate.
                postForEntity("http://localhost:" + port + "/consumer-tickets-ms/tickets/tickets-pricecalc-v1/tickets/purchase",ticketPurchaseRequestHttpEntity, ExceptionResponse.class);
        assertNotNull(exceptionResponse);
        assertTrue(exceptionResponse.getBody().getMessage().contains("Invalid"));
    }

    private TicketPurchaseRequest getTicketPurchaseRequest()  {

        TicketRequest ticketRequestAdult = new TicketRequest(TicketRequest.Type.ADULT , 1);
        TicketRequest ticketRequestChild = new TicketRequest(TicketRequest.Type.CHILD , 2);
        TicketRequest[] ticketRequests = new TicketRequest[2];
        ticketRequests[0] = ticketRequestAdult;
        ticketRequests[1] = ticketRequestChild;
        TicketPurchaseRequest ticketPurchaseRequest = new TicketPurchaseRequest(1234, ticketRequests);

       /* ObjectMapper mapper = new ObjectMapper();
        System.out.println("json:" + mapper.writeValueAsString(ticketPurchaseRequest));*/
        return ticketPurchaseRequest;
    }
}
