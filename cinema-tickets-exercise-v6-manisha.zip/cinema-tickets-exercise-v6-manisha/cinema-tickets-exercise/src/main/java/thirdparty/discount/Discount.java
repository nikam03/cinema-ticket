package thirdparty.discount;

public record Discount(double percentage) {
}
