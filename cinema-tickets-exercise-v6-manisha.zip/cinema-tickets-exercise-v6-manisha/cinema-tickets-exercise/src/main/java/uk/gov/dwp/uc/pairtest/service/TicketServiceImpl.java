package uk.gov.dwp.uc.pairtest.service;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import thirdparty.paymentgateway.TicketPaymentServiceImpl;
import thirdparty.seatbooking.SeatReservationService;
import uk.gov.dwp.uc.pairtest.config.PriceConfig;
import uk.gov.dwp.uc.pairtest.domain.TicketPurchaseRequest;
import uk.gov.dwp.uc.pairtest.domain.TicketPurchaseResponse;
import uk.gov.dwp.uc.pairtest.domain.TicketRequest;
import uk.gov.dwp.uc.pairtest.exception.InvalidPurchaseException;

import java.util.Arrays;
import java.util.List;
import java.util.Objects;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.stream.Collectors;

/**
 * This is the Service calls which take cinema purchase requests
 * 1. validates the request as per Business Rules
 * 2. calculates price and invokes third parties Payments System
 * 3. calculates no of seat to reserve and calls Seat Reservation System
 */
@Service
public class TicketServiceImpl implements TicketService, SeatReservationService {

    @Autowired
    private PriceConfig priceConfig;

    private static Logger logger = LogManager.getLogger();

    /**
     * Should only have private methods other than the one below.
     *
     * @return
     */
    @Override
    public TicketPurchaseResponse purchaseTickets(TicketPurchaseRequest ticketPurchaseRequest) throws Exception {

        validatePurchaseRequest(ticketPurchaseRequest);

        List<TicketRequest> ticketRequestList = Arrays.asList( ticketPurchaseRequest.ticketRequests());
        try {
            /** Ticket Price Calculation and Third Party Payment System call */
            logger.trace("Calculating ticket price for account : ", ticketPurchaseRequest.accountId());
            int totalPrice = calculateTicketPrice(ticketRequestList);

            /** No of Seat Calculation and Third Party Seat Reservation System call */
            int noOfSeats = getNoOfSeats(ticketRequestList);

            doPaymentAndReserveSeats(ticketPurchaseRequest.accountId(), totalPrice, noOfSeats);

            return new TicketPurchaseResponse(ticketPurchaseRequest.accountId(),totalPrice,noOfSeats);
        }catch (Exception exception){
            logger.error("Exception occurred while processing ticket purchase request", exception.getMessage());
            throw new Exception("Exception occurred while processing your request,please try again later...");
        }
    }

    private void doPaymentAndReserveSeats(long accountId, int totalprice, int noOfSeats) {
        new TicketPaymentServiceImpl().makePayment(accountId, totalprice);
        reserveSeat(accountId,noOfSeats);
    }

    private void validatePurchaseRequest(TicketPurchaseRequest ticketPurchaseRequest){
        if(Objects.isNull(ticketPurchaseRequest) || ticketPurchaseRequest.accountId()==0 ||
           (Objects.isNull(ticketPurchaseRequest.ticketRequests()) && ticketPurchaseRequest.ticketRequests().length==0)){
            throw new InvalidPurchaseException("Invalid ticket request");
        }
        List isListWithNoAdult =  Arrays.stream(ticketPurchaseRequest.ticketRequests()).filter(
                ticketRequest ->
                    ticketRequest.type() == TicketRequest.Type.ADULT
                ).collect(Collectors.toList());
        if(isListWithNoAdult.size()==0){
            logger.error("No adults assisting in cinema ticket booking,hence rejecting request..");
            throw new InvalidPurchaseException("Invalid ticket request");
        }

        if(Arrays.stream(ticketPurchaseRequest.ticketRequests()).mapToInt( obj -> obj.noOfTickets()).sum() > 20 )
        {
            logger.error("Sorry , you can only buy 20 tickets at a time");
            throw new InvalidPurchaseException("Sorry , you can only buy 20 tickets at a time");
        }
    }

    /**
     * Method to calculate tickets price based on no of user types and price model
     * Note: INFANTS are excluded from price calculation.
     * @param ticketRequestList
     * @return
     */
    private int calculateTicketPrice( List<TicketRequest> ticketRequestList){
       int ticketPrice =  ticketRequestList.stream().mapToInt(
                ticketRequest -> (int) (Double.parseDouble(priceConfig.getMappings().get(ticketRequest.type().name())) * ticketRequest.noOfTickets())).sum();
        logger.trace("Ticket price is {}" , ticketPrice);
       return  ticketPrice;
    }

    /**
     * Implmentation of Third Party and will remain as is
     * @param accountId
     * @param totalSeatsToAllocate
     */
    @Override
    public void reserveSeat(long accountId, int totalSeatsToAllocate) {
        /**
         *
         * seat reservation system call if third Party
         */
    }

    /**
     * Method to find no of seats to be allocated
     * Note: INFANTs will get no seat
     * @param ticketRequestList
     * @return
     */
    private int getNoOfSeats(List<TicketRequest> ticketRequestList){
        AtomicInteger noOfSeats = new AtomicInteger();
        ticketRequestList.forEach( ticketRequest -> {
            if (!ticketRequest.type().equals(TicketRequest.Type.INFANT)) {
                noOfSeats.addAndGet(ticketRequest.noOfTickets());
            }
        });
        logger.trace("No of Seats {}" , noOfSeats);
        return noOfSeats.get();
    }
}
