package uk.gov.dwp.uc.pairtest.domain;

/**
 * Should be an Immutable Object
 */
public record TicketRequest (Type type, int noOfTickets) {
    public enum Type {
        ADULT, CHILD , INFANT
    }

}
