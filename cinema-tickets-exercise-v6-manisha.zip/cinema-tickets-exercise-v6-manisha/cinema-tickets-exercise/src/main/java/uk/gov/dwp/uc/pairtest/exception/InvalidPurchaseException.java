package uk.gov.dwp.uc.pairtest.exception;

import java.util.Date;

public class InvalidPurchaseException extends RuntimeException {


    private static final long serialVersionUID = 1L;

    public InvalidPurchaseException(String exception) {
        super(exception);
    }

}
