package uk.gov.dwp.uc.pairtest.service;

import uk.gov.dwp.uc.pairtest.domain.TicketPurchaseRequest;
import uk.gov.dwp.uc.pairtest.domain.TicketPurchaseResponse;

public interface TicketService {

    TicketPurchaseResponse purchaseTickets(TicketPurchaseRequest ticketPurchaseRequest) throws Exception;

}
