package uk.gov.dwp.uc.pairtest;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TicketPurchaseApplication {

    public static void main(String[] args)  {
        SpringApplication.run(TicketPurchaseApplication.class, args);
    }
}
