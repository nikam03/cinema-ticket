package uk.gov.dwp.uc.pairtest.constants;

public interface TicketConstants {

    String CONTROLLER_PATH = "/tickets";
}