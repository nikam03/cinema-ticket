package uk.gov.dwp.uc.pairtest.domain;

/**
 * Response Class
 */
public record TicketPurchaseResponse(long accountId, int totalPrice,int noOfSeats) {
}
