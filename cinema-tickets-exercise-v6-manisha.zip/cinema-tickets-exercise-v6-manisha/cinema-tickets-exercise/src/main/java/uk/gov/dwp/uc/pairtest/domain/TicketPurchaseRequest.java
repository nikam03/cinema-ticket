package uk.gov.dwp.uc.pairtest.domain;

import javax.validation.constraints.NotNull;

/**
 * Please make this an Immutable Object
 * Added Record to make this an Immutable Object
 */
public record TicketPurchaseRequest (long accountId, TicketRequest[] ticketRequests) {
}
