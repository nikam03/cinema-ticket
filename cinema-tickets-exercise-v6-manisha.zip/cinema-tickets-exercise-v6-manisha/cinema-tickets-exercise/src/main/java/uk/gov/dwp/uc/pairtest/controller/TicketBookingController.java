package uk.gov.dwp.uc.pairtest.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import uk.gov.dwp.uc.pairtest.constants.TicketConstants;
import uk.gov.dwp.uc.pairtest.domain.TicketPurchaseRequest;
import uk.gov.dwp.uc.pairtest.domain.TicketPurchaseResponse;
import uk.gov.dwp.uc.pairtest.service.TicketService;

import javax.validation.Valid;

import static org.springframework.http.MediaType.APPLICATION_JSON_VALUE;

/**
 * This is controller class which entry point for
 * all rest calls of cinema purchase application
 * @author  Manisha Nikambe
 */
@RestController
@RequestMapping(TicketConstants.CONTROLLER_PATH)
public class TicketBookingController {

    @Autowired
    private TicketService ticketService;


    @PostMapping(value = "/purchase", produces = APPLICATION_JSON_VALUE, consumes = APPLICATION_JSON_VALUE)
    public ResponseEntity<TicketPurchaseResponse> purchaseTickets(@RequestBody @Valid TicketPurchaseRequest ticketPurchaseRequest) throws Exception {
        return new ResponseEntity<>( ticketService.purchaseTickets(ticketPurchaseRequest), HttpStatus.OK);
    }


}
