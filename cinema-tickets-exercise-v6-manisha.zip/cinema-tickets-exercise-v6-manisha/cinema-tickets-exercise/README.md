# Cinema Tickets Application
This is cinema tickets purchase application which does payments of the end user and seat reservation 

## Business Rules
- There are 3 types of tickets i.e. Infant, Child, and Adult.
- The ticket prices are based on the type of ticket (see table below).
- The ticket purchaser declares how many and what type of tickets they want to buy.
- Multiple tickets can be purchased at any given time.
- Only a maximum of 20 tickets that can be purchased at a time.
- Infants do not pay for a ticket and are not allocated a seat. They will be sitting on an Adult's lap.
- Child and Infant tickets cannot be purchased without purchasing an Adult ticket.

| Ticket Type | Price |
|-------------|-------|
| INFANT      | £0    |
| CHILD       | £10   |
| ADULT       | £20   |

- There is an existing third party TicketPaymentService responsible for taking payments.
- There is an existing third party SeatReservationService responsible for reserving seats.

## Prerequisites

* At least JDK version 17 and above
* Java IDE, you can use any IDE example:
    * Eclipse
    * Intellij
* Maven

## Technical Overview
This is spring boot application exposing POST call to purchase movie tickets which has currently one post call 
to process cinema purchase request

## Installations

unzip the cinema-tickets-exercise.zip folder on your computer

```bash
./mvnw clean install
```

## Tests and checks

To run all tests:

```bash
./mvnw verify
```

## Run locally
To start the service locally at http://localhost:8090/consumer-tickets-ms/tickets/tickets-pricecalc-v1/tickets/purchase
```bash
./mvnw spring-boot:run
```

To interact with it:
```bash
# interact - health of application
curl --location 'http://localhost:8090/consumer-tickets-ms/tickets/tickets-pricecalc-v1/actuator/health'
# interact - purchase movie ticket
curl --location 'http://localhost:8090/consumer-tickets-ms/tickets/tickets-pricecalc-v1/tickets/purchase' \
--header 'Content-Type: application/json' \
--data '{
    "accountId": 1234,
    "ticketRequests": [
        {
            "type": "ADULT",
            "noOfTickets": 15
        },
          {
            "type": "CHILD",
            "noOfTickets": 3
        }
    ]
}'
```

## Create production jar
To create a production jar locally run:
```bash
./mvnw clean package spring-boot:repackage
```

## Postman Collection

Find a given Postman collection under ./cinema-tickets-exercise/cinema-tickets-exercise.postman_collection.json

## Architectural and Design Decisions
1. Externalisation of microservice versioning through application.yaml (if Blue Green deployment strategy used)
2. Ticket prices and microservice version has been externalized using application.yaml for future ease of enhancements 

## Future Enhancements
1. Addition of Service layer Junits
2. Handling Payment and Seat allocation through one transaction to avoid inconsistency