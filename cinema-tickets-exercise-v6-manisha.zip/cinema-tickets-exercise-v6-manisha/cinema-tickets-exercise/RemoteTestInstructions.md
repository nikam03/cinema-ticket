# Cinema Tickets Exercise - V6

This is a coding exercise which will allow you to demonstrate how you code and your approach to a given problem.

- Please **DO NOT** publish your submission to GitHub or any other public repository, this test is proprietary and should not be made public.
- When returning the completed test, could you please complete it in **Java 17** and send it as a zip file to the email address provided.
- Run a 'mvn clean' prior to zipping the solution, and ensure that your submission does not contain any .sh, .bat, .class
- By submitting your solution to us you assert that it is wholly your original work and not a copy. Copied submissions will be identified and immediately disqualified.
- There is no stated time limit but allow at least few hours.
- The important thing is to arrive at a solution that you are satisfied with and comfortable discussing with others.

## Assessment Criteria

You will be assessed on:
- You demonstrating that you can follow instructions laid out in the business rules, constraints and assumptions below.
- Your ability to write clean, well-tested and reusable code.
- How you have completed the task and ensured ALL the requirement (i.e. business rules) has been correctly met.

## Business Rules

- There are 3 types of tickets i.e. Infant, Child, and Adult.
- The ticket prices are based on the type of ticket (see table below).
- The ticket purchaser declares how many and what type of tickets they want to buy.
- Multiple tickets can be purchased at any given time.
- Only a maximum of 20 tickets that can be purchased at a time.
- Infants do not pay for a ticket and are not allocated a seat. They will be sitting on an Adult's lap.
- Child and Infant tickets cannot be purchased without purchasing an Adult ticket.

| Ticket Type | Price |
|-------------|-------|
| INFANT      | £0    |
| CHILD       | £10   |
| ADULT       | £20   |

- There is an existing third party TicketPaymentService responsible for taking payments.
- There is an existing third party SeatReservationService responsible for reserving seats.

## Constraints

- The TicketService interface **CANNOT** be modified.
- Any Java code in the thirdparty.* packages **CANNOT** be modified.
- Please ignore the DiscountService and any classes in the **thirparty.discount** package.

## Assumptions

You can assume:
- All accounts with an id greater than zero are valid. They also have sufficient funds to pay for any no of tickets.
- The TicketPaymentService implementation is an external provider with no defects. You do not need to worry about how the actual payment happens.
- The payment will always go through once a payment request has been made to the TicketPaymentService.
- The SeatReservationService implementation is an external provider with no defects. You do not need to worry about how the seat reservation algorithm works.
- The seat will always be reserved once a reservation request has been made to the SeatReservationService.


## Your Task

Provide a working implementation of a TicketService that:

- Considers the above objective, business rules, constraints & assumptions.
- Calculates the correct amount for the requested tickets and makes a payment request to the TicketPaymentService.
- Calculates the correct no of seats to reserve and makes a seat reservation request to the SeatReservationService.
- Rejects any invalid ticket purchase requests. It is up to you to identify what should be deemed as an invalid purchase request.
- Please email your completed solution in a zip file within 7 days of receipt of this test.
- On receipt of your completed test, we will contact you via your civil service jobs account, to advise if you have been successful in being progressed to the next stage, which will be a video interview.
